# Technical Design Document

## 1. Purpose and scope

The Aqua Autonomous Bot removes floating waste from the **water surface** of small lakes and ponds. A catamaran hull funnels debris through a 20 cm open front channel onto a conveyor that lifts it into a mesh basket. Sub-surface cleaning is out of scope.

Two builds share this design:

| | Prototype (this repository) | Full-scale design |
|---|---|---|
| Size | under 50 cm | 1.2 m x 0.9 m x 0.5 m |
| Compute | Raspberry Pi (Zero 2 W or 4) | Raspberry Pi 5 |
| Propulsion | 2 small DC motors | 2 x 50 W BLDC thrusters |
| Power | 2S 18650 + small solar panel | 100 W solar panel + 48 V LiFePO4 pack |

## 2. System architecture

```mermaid
flowchart LR
    subgraph Sensors
        GPS[NEO-6M GPS<br/>UART]
        CMP[QMC5883L compass<br/>I2C]
        SON[JSN-SR04T sonar<br/>GPIO]
        CAM[Camera]
    end
    subgraph Pi[Raspberry Pi]
        DET[YOLOv8n detector]
        NAV[Waypoint navigator]
        CTL[Controller 10 Hz<br/>modes, safety rules]
        WEB[Flask dashboard]
    end
    subgraph Actuators
        DRV[TB6612FNG drivers]
        TL[Left thruster]
        TR[Right thruster]
        CNV[Conveyor motor]
        RLY[E-stop relay]
    end
    GPS --> CTL
    CMP --> CTL
    SON --> CTL
    CAM --> DET --> CTL
    CTL <--> NAV
    WEB <--> CTL
    CTL --> DRV --> TL
    DRV --> TR
    DRV --> CNV
    CTL --> RLY
    Phone[Phone browser] <-->|Wi-Fi| WEB
```

## 3. Control logic

```mermaid
flowchart TD
    A[Start of cycle] --> B{E-stop?}
    B -- yes --> Z[Motors and conveyor off, relay opens]
    B -- no --> C{Mode}
    C -- MANUAL --> D{Command within dead-man time?}
    D -- no --> Z2[Stop]
    D -- yes --> E{Forward and obstacle near?}
    E -- yes --> Z2
    E -- no --> M[Apply manual command]
    C -- AUTO --> F{GPS fix?}
    F -- no --> Z2
    F -- yes --> G{Obstacle near?}
    G -- yes --> H[Back off and turn away]
    G -- no --> I[Navigator: bearing error to thruster commands]
    C -- IDLE --> Z2
```

**Navigation:** the bearing from the current GPS position to the next waypoint is compared with the compass heading. The error is wrapped to [-180, 180) degrees; a proportional term sets the left/right thrust difference. Forward speed is reduced as the error grows and the boat pivots in place beyond 90 degrees. A waypoint counts as reached inside `AQUA_ARRIVAL_RADIUS_M`.

**Conveyor:** runs in Auto mode (or when switched on in Manual) and speeds up by 40% when the detector reports debris.

## 4. Wiring (BCM pin numbers)

| Signal | Pi pin (BCM) | Goes to |
|---|---|---|
| Left thruster IN1 / IN2 / PWM | 5 / 6 / 12 | Driver A, channel A |
| Right thruster IN1 / IN2 / PWM | 16 / 20 / 13 | Driver A, channel B |
| Conveyor IN1 / IN2 / PWM | 23 / 24 / 18 | Driver B, channel A |
| Driver STBY | 25 | Both drivers' STBY |
| Sonar TRIG | 17 | JSN-SR04T TRIG |
| Sonar ECHO | 27 | JSN-SR04T ECHO **through a divider** (for example 1 k and 2 k) |
| E-stop relay | 22 | Relay module input |
| GPS TX / RX | 15 / 14 (UART) | NEO-6M TX / RX (crossed) |
| Compass SDA / SCL | 2 / 3 (I2C) | QMC5883L SDA / SCL |

Pin numbers are defined once in `aqua_bot/config.py`.

## 5. Power

```mermaid
flowchart LR
    SOL[Solar panel] --> CHG[Charge controller]
    CHG --> BMS[2S BMS]
    BAT[2 x 18650, 2S] <--> BMS
    BMS --> RLY[E-stop relay] --> DRV[Motor drivers VM]
    BMS --> BUCK[LM2596 buck 5 V] --> PI[Raspberry Pi and sensors]
```

- The motors and the Pi are on separate branches so motor surges do not reset the Pi.
- The relay cuts motor power only; the Pi stays on so the dashboard keeps working after an emergency stop.
- Fit a fuse on the battery output and size the buck converter for the Pi model in use (a Pi 5 needs a much stronger 5 V supply than a Pi Zero 2 W).
- Add decoupling capacitors close to each motor driver.

## 6. Waterproofing and buoyancy notes

- Seal pipe hulls with end caps and PVC cement, then silicone; route cables through glands.
- Keep electronics on the deck in a splash-proof box, not inside the hulls.
- Check buoyancy with the full load plus a full basket in a bucket or tank before any water trial.
- The ultrasonic sensor and GPS antenna must face outward with a clear view.

## 7. Test plan

| # | Test | Pass condition | Type |
|---|---|---|---|
| 1 | Geodesy and NMEA parsing | `tests/test_geo.py`, `tests/test_gps_parser.py` pass | Automated |
| 2 | Navigation steering and arrival | `tests/test_navigation.py` passes | Automated |
| 3 | Controller safety rules | `tests/test_controller.py` passes | Automated |
| 4 | Simulated mission through all sample waypoints | `test_simulated_mission_reaches_all_waypoints` passes | Automated |
| 5 | Dashboard API | `tests/test_dashboard.py` passes | Automated |
| 6 | Bench: each motor direction and the conveyor | Directions match the dashboard buttons | Manual |
| 7 | Bench: emergency stop | Motors stop and the relay opens within one cycle | Manual |
| 8 | Bench: sonar at known distances | Readings within a few cm of a tape measure | Manual |
| 9 | Outdoor: GPS fix and compass heading | Fix acquired; heading matches a phone compass | Manual |
| 10 | Pool: manual drive, then collection of floating test items | Items reach the basket | Manual |
| 11 | Pond: short Auto run on a 2 to 4 point loop | Boat reaches waypoints; obstacle stop works | Manual |

Record results from tests 6 to 11 in `docs/test_log.md` once they are done.

## 8. Known limitations

- Hardware drivers have not yet been validated on the finished boat.
- The debris model uses stock weights; a floating-waste dataset is needed for good accuracy.
- Heading comes from a magnetometer only, so it needs careful calibration away from motors and magnets.
- There is no weed or entanglement detection beyond monitoring conveyor behaviour.

## 9. Future work

- Fine-tune YOLOv8n on floating-debris images from local water bodies
- Motor current sensing to detect conveyor jams and trigger reverse-run
- MQTT telemetry and a map view
- Low-battery return to start point
