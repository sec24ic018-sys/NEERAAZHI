"""Minimal NMEA GGA parser with checksum validation (no external dependencies)."""
from typing import Optional, Tuple


def checksum_ok(sentence: str) -> bool:
    s = sentence.strip()
    if not s.startswith("$") or "*" not in s:
        return False
    body, _, given = s[1:].partition("*")
    calc = 0
    for ch in body:
        calc ^= ord(ch)
    try:
        return calc == int(given[:2], 16)
    except ValueError:
        return False


def _to_deg(value: str, hemi: str) -> float:
    dot = value.index(".")
    deg = float(value[:dot - 2])
    minutes = float(value[dot - 2:])
    out = deg + minutes / 60.0
    return -out if hemi in ("S", "W") else out


def parse_gga(sentence: str) -> Optional[Tuple[float, float]]:
    """Return (lat, lon) from a valid GGA sentence with a fix, otherwise None."""
    if not checksum_ok(sentence):
        return None
    parts = sentence.strip().split("*")[0].split(",")
    if not parts[0].endswith("GGA") or len(parts) < 7:
        return None
    if parts[6] in ("", "0"):          # fix quality 0 = no fix
        return None
    try:
        return _to_deg(parts[2], parts[3]), _to_deg(parts[4], parts[5])
    except (ValueError, IndexError):
        return None
