"""Simple kinematic boat model so the whole control stack runs on a laptop."""
import math


class _SimConveyor:
    def __init__(self, boat):
        self._b = boat

    def set(self, s):
        self._b.conveyor = s

    def stop(self):
        self._b.conveyor = 0.0


class SimBoat:
    """Acts as the motors object and the e-stop relay; use the helper classes for sensors."""

    def __init__(self, lat=13.0, lon=80.0, heading=0.0, max_speed_mps=1.0, yaw_gain_deg_s=60.0):
        self.lat, self.lon, self.heading = lat, lon, heading
        self.max_speed = max_speed_mps
        self.yaw_gain = yaw_gain_deg_s
        self.left = self.right = 0.0
        self.conveyor = 0.0
        self.obstacle_cm = 400.0
        self.debris = 0
        self.power_ok = True

    @property
    def conveyor_device(self):
        return _SimConveyor(self)

    def set(self, left, right):
        self.left, self.right = left, right

    def stop(self):
        self.left = self.right = 0.0

    def allow(self, ok):
        self.power_ok = ok

    def step(self, dt):
        if not self.power_ok:
            return
        speed = (self.left + self.right) / 2 * self.max_speed
        self.heading = (self.heading + (self.left - self.right) * self.yaw_gain * dt) % 360
        h = math.radians(self.heading)
        self.lat += speed * math.cos(h) * dt / 111320.0
        self.lon += speed * math.sin(h) * dt / (111320.0 * math.cos(math.radians(self.lat)))


class SimCompass:
    def __init__(self, boat):
        self._b = boat

    def heading(self):
        return self._b.heading


class SimGPS:
    def __init__(self, boat):
        self._b = boat

    def read(self):
        return (self._b.lat, self._b.lon)


class SimSonar:
    def __init__(self, boat):
        self._b = boat

    def distance_cm(self):
        return self._b.obstacle_cm


class SimDetector:
    def __init__(self, boat):
        self._b = boat

    def count(self):
        return self._b.debris
