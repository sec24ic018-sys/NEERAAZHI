"""Waypoint navigation: turns (position, heading) into left/right thruster commands."""
from dataclasses import dataclass
from typing import List

from .geo import bearing_deg, haversine_m, wrap_180


@dataclass
class Waypoint:
    lat: float
    lon: float


@dataclass
class NavCommand:
    left: float
    right: float
    done: bool
    distance_m: float
    bearing_deg: float
    waypoint_index: int


def _clamp(v, lo=-1.0, hi=1.0):
    return max(lo, min(hi, v))


class WaypointNavigator:
    def __init__(self, waypoints: List[Waypoint], arrival_radius_m=3.0,
                 base_speed=0.6, kp=0.015, max_turn=0.5):
        self.waypoints = list(waypoints)
        self.arrival_radius_m = arrival_radius_m
        self.base_speed = base_speed
        self.kp = kp
        self.max_turn = max_turn
        self.index = 0

    def reset(self):
        self.index = 0

    @property
    def done(self):
        return self.index >= len(self.waypoints)

    def update(self, lat, lon, heading_deg) -> NavCommand:
        if self.done:
            return NavCommand(0.0, 0.0, True, 0.0, 0.0, self.index)
        wp = self.waypoints[self.index]
        dist = haversine_m(lat, lon, wp.lat, wp.lon)
        if dist <= self.arrival_radius_m:
            self.index += 1
            if self.done:
                return NavCommand(0.0, 0.0, True, dist, 0.0, self.index)
            wp = self.waypoints[self.index]
            dist = haversine_m(lat, lon, wp.lat, wp.lon)
        brg = bearing_deg(lat, lon, wp.lat, wp.lon)
        err = wrap_180(brg - heading_deg)          # + means target is to the right
        turn = _clamp(self.kp * err, -self.max_turn, self.max_turn)
        forward = self.base_speed * max(0.0, 1.0 - abs(err) / 90.0)   # pivot when badly misaligned
        if abs(err) > 90:
            turn = self.max_turn if err > 0 else -self.max_turn
        left = _clamp(forward + turn)
        right = _clamp(forward - turn)
        return NavCommand(left, right, False, dist, brg, self.index)
