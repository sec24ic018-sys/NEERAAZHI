"""Runtime configuration, read from environment variables (see .env.example)."""
import os
from dataclasses import dataclass, field


def _f(name, default):
    return float(os.getenv(name, default))


def _i(name, default):
    return int(os.getenv(name, default))


@dataclass
class Config:
    host: str = field(default_factory=lambda: os.getenv("AQUA_HOST", "0.0.0.0"))
    port: int = field(default_factory=lambda: _i("AQUA_PORT", 8000))
    waypoints_file: str = field(default_factory=lambda: os.getenv("AQUA_WAYPOINTS", "sample_data/waypoints.json"))
    gps_port: str = field(default_factory=lambda: os.getenv("AQUA_GPS_PORT", "/dev/serial0"))
    gps_baud: int = field(default_factory=lambda: _i("AQUA_GPS_BAUD", 9600))
    i2c_bus: int = field(default_factory=lambda: _i("AQUA_I2C_BUS", 1))
    mag_declination_deg: float = field(default_factory=lambda: _f("AQUA_MAG_DECLINATION_DEG", 0.0))
    obstacle_stop_cm: float = field(default_factory=lambda: _f("AQUA_OBSTACLE_STOP_CM", 60))
    arrival_radius_m: float = field(default_factory=lambda: _f("AQUA_ARRIVAL_RADIUS_M", 3.0))
    base_speed: float = field(default_factory=lambda: _f("AQUA_BASE_SPEED", 0.6))
    conveyor_speed: float = field(default_factory=lambda: _f("AQUA_CONVEYOR_SPEED", 0.5))
    deadman_s: float = field(default_factory=lambda: _f("AQUA_DEADMAN_S", 1.0))
    yolo_model: str = field(default_factory=lambda: os.getenv("AQUA_YOLO_MODEL", "yolov8n.pt"))
    camera_index: int = field(default_factory=lambda: _i("AQUA_CAMERA_INDEX", 0))
    detect_conf: float = field(default_factory=lambda: _f("AQUA_DETECT_CONF", 0.4))


# BCM pin map (see docs/TECHNICAL_DESIGN.md for the wiring diagram)
PINS = {
    "thruster_left":  {"in1": 5,  "in2": 6,  "pwm": 12},
    "thruster_right": {"in1": 16, "in2": 20, "pwm": 13},
    "conveyor":       {"in1": 23, "in2": 24, "pwm": 18},
    "sonar_trig": 17,
    "sonar_echo": 27,   # through a 5V -> 3.3V divider
    "estop_relay": 22,
    "driver_standby": 25,
}
