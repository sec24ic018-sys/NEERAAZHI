"""Main control loop: manual drive, GPS waypoint autonomy, obstacle avoidance, e-stop."""
import threading
import time

IDLE, MANUAL, AUTO = "IDLE", "MANUAL", "AUTO"


class AquaBotController:
    def __init__(self, motors, conveyor, sonar, gps, compass, navigator, cfg,
                 detector=None, estop_relay=None, clock=time.monotonic):
        self.motors, self.conveyor, self.sonar = motors, conveyor, sonar
        self.gps, self.compass, self.nav, self.cfg = gps, compass, navigator, cfg
        self.detector, self.relay, self.clock = detector, estop_relay, clock
        self.mode = IDLE
        self.estop = False
        self.manual = (0.0, 0.0)
        self.conveyor_on = False
        self._last_manual = 0.0
        self._lock = threading.Lock()
        self.status = {}

    # ---- commands (called from the web dashboard) ----
    def set_mode(self, mode):
        with self._lock:
            if mode in (IDLE, MANUAL, AUTO):
                self.mode = mode
                if mode == AUTO:
                    self.nav.reset()

    def drive(self, left, right):
        with self._lock:
            self.manual = (max(-1, min(1, left)), max(-1, min(1, right)))
            self._last_manual = self.clock()
            if self.mode == IDLE:
                self.mode = MANUAL

    def set_conveyor(self, on):
        with self._lock:
            self.conveyor_on = bool(on)

    def set_estop(self, active):
        with self._lock:
            self.estop = bool(active)

    # ---- one control cycle ----
    def step(self):
        with self._lock:
            mode, estop, manual = self.mode, self.estop, self.manual
            conv_on, last = self.conveyor_on, self._last_manual
        left = right = 0.0
        note = ""
        dist = self.sonar.distance_cm() if self.sonar else 999.0
        blocked = dist < self.cfg.obstacle_stop_cm
        debris = self.detector.count() if self.detector else 0

        if estop:
            note = "EMERGENCY STOP"
            conv_on = False
        elif mode == MANUAL:
            if self.clock() - last <= self.cfg.deadman_s:
                left, right = manual
            else:
                note = "deadman timeout"
            if blocked and (left + right) > 0:
                left = right = 0.0
                note = "obstacle: forward blocked"
        elif mode == AUTO:
            fix = self.gps.read()
            if fix is None:
                note = "waiting for GPS fix"
            elif blocked:
                left, right = -0.3, 0.3          # back off and turn away
                note = "obstacle avoidance"
            else:
                cmd = self.nav.update(fix[0], fix[1], self.compass.heading())
                left, right = cmd.left, cmd.right
                note = "mission complete" if cmd.done else f"to waypoint {cmd.waypoint_index}"
                self.status["distance_m"] = round(cmd.distance_m, 1)
            conv_on = True

        if self.relay:
            self.relay.allow(not estop)
        if estop:
            self.motors.stop()
        else:
            self.motors.set(left, right)
        if conv_on:
            speed = self.cfg.conveyor_speed * (1.4 if debris else 1.0)
            self.conveyor.set(min(1.0, speed))
        else:
            self.conveyor.stop()
        self.status.update(mode=mode, estop=estop, left=round(left, 2), right=round(right, 2),
                           sonar_cm=round(dist, 1), debris=debris, conveyor=conv_on, note=note)
        return self.status

    def run(self, hz=10, stop_event=None):
        period = 1.0 / hz
        while not (stop_event and stop_event.is_set()):
            self.step()
            time.sleep(period)
