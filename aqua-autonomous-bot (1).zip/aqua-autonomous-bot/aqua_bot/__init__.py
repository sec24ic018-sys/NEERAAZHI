"""Aqua Autonomous Bot: surface waste collection catamaran controller (Raspberry Pi)."""
__version__ = "0.1.0"
