"""Entry point:  python -m aqua_bot.main [--simulate]"""
import argparse
import json
import threading
import time

from .config import Config
from .controller import AquaBotController
from .dashboard import create_app
from .navigation import Waypoint, WaypointNavigator


def load_waypoints(path):
    with open(path) as f:
        return [Waypoint(w["lat"], w["lon"]) for w in json.load(f)["waypoints"]]


def build(cfg, simulate):
    nav = WaypointNavigator(load_waypoints(cfg.waypoints_file), cfg.arrival_radius_m, cfg.base_speed)
    if simulate:
        from .simulation import SimBoat, SimCompass, SimDetector, SimGPS, SimSonar
        first = nav.waypoints[0]
        boat = SimBoat(lat=first.lat - 0.0002, lon=first.lon)
        ctrl = AquaBotController(boat, boat.conveyor_device, SimSonar(boat), SimGPS(boat),
                                 SimCompass(boat), nav, cfg, detector=SimDetector(boat), estop_relay=boat)
        return ctrl, boat
    from . import hardware as hw
    ctrl = AquaBotController(hw.Motors(), hw.Conveyor(), hw.Sonar(), hw.GPS(cfg.gps_port, cfg.gps_baud),
                             hw.Compass(cfg.i2c_bus, cfg.mag_declination_deg), nav, cfg,
                             detector=hw.Detector(cfg.yolo_model, cfg.camera_index, cfg.detect_conf),
                             estop_relay=hw.EStopRelay())
    return ctrl, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--simulate", action="store_true", help="run without hardware")
    args = ap.parse_args()
    cfg = Config()
    ctrl, boat = build(cfg, args.simulate)
    stop = threading.Event()
    threading.Thread(target=ctrl.run, kwargs={"stop_event": stop}, daemon=True).start()
    if boat:
        def physics():
            while not stop.is_set():
                boat.step(0.1)
                time.sleep(0.1)
        threading.Thread(target=physics, daemon=True).start()
    try:
        create_app(ctrl).run(host=cfg.host, port=cfg.port)
    finally:
        stop.set()
        ctrl.motors.stop()
        ctrl.conveyor.stop()


if __name__ == "__main__":
    main()
