"""Real hardware drivers for the Raspberry Pi. Imports are lazy so the rest of the
package (and the tests) run on any computer."""
import math
import time

from .config import PINS
from .gps_parser import parse_gga


class Motors:
    """Left/right thrusters through TB6612FNG-style drivers (IN1, IN2, PWM)."""

    def __init__(self):
        from gpiozero import DigitalOutputDevice, Motor
        p = PINS
        self._standby = DigitalOutputDevice(p["driver_standby"], initial_value=True)
        self._l = Motor(p["thruster_left"]["in1"], p["thruster_left"]["in2"], enable=p["thruster_left"]["pwm"], pwm=True)
        self._r = Motor(p["thruster_right"]["in1"], p["thruster_right"]["in2"], enable=p["thruster_right"]["pwm"], pwm=True)

    def set(self, left, right):
        self._l.value = max(-1, min(1, left))
        self._r.value = max(-1, min(1, right))

    def stop(self):
        self._l.stop()
        self._r.stop()


class Conveyor:
    def __init__(self):
        from gpiozero import Motor
        c = PINS["conveyor"]
        self._m = Motor(c["in1"], c["in2"], enable=c["pwm"], pwm=True)

    def set(self, speed):
        self._m.value = max(0, min(1, speed))

    def stop(self):
        self._m.stop()


class EStopRelay:
    """Relay that cuts motor power. Energised = power allowed."""

    def __init__(self):
        from gpiozero import DigitalOutputDevice
        self._relay = DigitalOutputDevice(PINS["estop_relay"], initial_value=True)

    def allow(self, ok: bool):
        self._relay.value = bool(ok)


class Sonar:
    """JSN-SR04T waterproof ultrasonic (trigger/echo). ECHO must pass a 5V->3.3V divider."""

    def __init__(self):
        from gpiozero import DistanceSensor
        self._s = DistanceSensor(echo=PINS["sonar_echo"], trigger=PINS["sonar_trig"], max_distance=4.0)

    def distance_cm(self):
        return self._s.distance * 100.0


class GPS:
    def __init__(self, port, baud):
        import serial
        self._ser = serial.Serial(port, baud, timeout=0.5)
        self._last = None

    def read(self):
        """Return the latest (lat, lon) or None if no fix yet."""
        deadline = time.time() + 0.3
        while time.time() < deadline and self._ser.in_waiting:
            line = self._ser.readline().decode("ascii", errors="ignore")
            fix = parse_gga(line)
            if fix:
                self._last = fix
        return self._last


class Compass:
    """QMC5883L magnetometer over I2C (address 0x0D). Calibrate before real use."""

    def __init__(self, bus=1, declination_deg=0.0, offset=(0.0, 0.0)):
        from smbus2 import SMBus
        self._bus = SMBus(bus)
        self._addr = 0x0D
        self._decl = declination_deg
        self._off = offset
        self._bus.write_byte_data(self._addr, 0x0B, 0x01)   # set/reset period
        self._bus.write_byte_data(self._addr, 0x09, 0x1D)   # 512 OSR, 8G, 200Hz, continuous

    def heading(self):
        d = self._bus.read_i2c_block_data(self._addr, 0x00, 6)
        x = self._s16(d[0], d[1]) - self._off[0]
        y = self._s16(d[2], d[3]) - self._off[1]
        return (math.degrees(math.atan2(y, x)) + self._decl + 360) % 360

    @staticmethod
    def _s16(lo, hi):
        v = (hi << 8) | lo
        return v - 65536 if v & 0x8000 else v


class Detector:
    """YOLOv8n floating-debris detector fed by the camera."""

    def __init__(self, model_path, camera_index=0, conf=0.4):
        import cv2
        from ultralytics import YOLO
        self._model = YOLO(model_path)
        self._cap = cv2.VideoCapture(camera_index)
        self._conf = conf

    def count(self):
        ok, frame = self._cap.read()
        if not ok:
            return 0
        res = self._model.predict(frame, conf=self._conf, verbose=False)
        return len(res[0].boxes)
