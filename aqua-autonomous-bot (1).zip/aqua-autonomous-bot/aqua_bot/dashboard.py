"""Flask dashboard for manual drive, conveyor control, e-stop and status."""
from flask import Flask, jsonify, request

PAGE = """<!doctype html><meta name=viewport content="width=device-width,initial-scale=1">
<title>Aqua Bot</title>
<style>body{font-family:sans-serif;text-align:center;margin:12px}button{font-size:1.4rem;margin:6px;padding:16px 22px;border-radius:10px;border:1px solid #888}
.stop{background:#c0392b;color:#fff}.row{margin:6px}pre{text-align:left;background:#f2f2f2;padding:8px}</style>
<h2>Aqua Autonomous Bot</h2>
<div class=row><button onclick="mode('MANUAL')">Manual</button><button onclick="mode('AUTO')">Auto</button><button onclick="mode('IDLE')">Idle</button></div>
<div class=row><button data-d="0.7,0.7">Forward</button></div>
<div class=row><button data-d="-0.5,0.5">Left</button><button data-d="-0.5,-0.5">Reverse</button><button data-d="0.5,-0.5">Right</button></div>
<div class=row><button onclick="post('/api/conveyor',{on:true})">Conveyor ON</button><button onclick="post('/api/conveyor',{on:false})">Conveyor OFF</button></div>
<div class=row><button class=stop onclick="post('/api/estop',{active:true})">E-STOP</button><button onclick="post('/api/estop',{active:false})">Reset</button></div>
<pre id=s></pre>
<script>
const post=(u,b)=>fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
const mode=m=>post('/api/mode',{mode:m});
document.querySelectorAll('button[data-d]').forEach(b=>{
 const [l,r]=b.dataset.d.split(',').map(Number);
 let t=null;
 const go=()=>{if(t)return;post('/api/drive',{left:l,right:r});t=setInterval(()=>post('/api/drive',{left:l,right:r}),300)};
 const end=()=>{if(!t)return;clearInterval(t);t=null;post('/api/drive',{left:0,right:0})};
 b.onpointerdown=go;b.onpointerup=end;b.onpointerleave=end;b.onpointercancel=end;
});
setInterval(async()=>{s.textContent=JSON.stringify(await (await fetch('/api/status')).json(),null,1)},700);
</script>"""


def create_app(controller):
    app = Flask(__name__)

    @app.get("/")
    def index():
        return PAGE

    @app.get("/api/status")
    def status():
        return jsonify(controller.status)

    @app.post("/api/mode")
    def mode():
        controller.set_mode((request.get_json(silent=True) or {}).get("mode", "IDLE"))
        return jsonify(ok=True)

    @app.post("/api/drive")
    def drive():
        d = request.get_json(silent=True) or {}
        controller.drive(float(d.get("left", 0)), float(d.get("right", 0)))
        return jsonify(ok=True)

    @app.post("/api/conveyor")
    def conveyor():
        controller.set_conveyor((request.get_json(silent=True) or {}).get("on", False))
        return jsonify(ok=True)

    @app.post("/api/estop")
    def estop():
        controller.set_estop((request.get_json(silent=True) or {}).get("active", True))
        return jsonify(ok=True)

    return app
