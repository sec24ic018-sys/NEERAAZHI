import json
import pathlib

from aqua_bot.config import Config
from aqua_bot.controller import AUTO, MANUAL, AquaBotController
from aqua_bot.navigation import Waypoint, WaypointNavigator
from aqua_bot.simulation import SimBoat, SimCompass, SimDetector, SimGPS, SimSonar


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def make(waypoints=((13.0003, 80.0),), lat=13.0, lon=80.0, heading=0.0):
    cfg = Config()
    boat = SimBoat(lat=lat, lon=lon, heading=heading)
    nav = WaypointNavigator([Waypoint(*w) for w in waypoints], cfg.arrival_radius_m, cfg.base_speed)
    clock = FakeClock()
    ctrl = AquaBotController(boat, boat.conveyor_device, SimSonar(boat), SimGPS(boat), SimCompass(boat),
                             nav, cfg, detector=SimDetector(boat), estop_relay=boat, clock=clock)
    return ctrl, boat, clock


def test_manual_drive_and_deadman_timeout():
    ctrl, boat, clock = make()
    ctrl.set_mode(MANUAL)
    ctrl.drive(0.7, 0.7)
    ctrl.step()
    assert (boat.left, boat.right) == (0.7, 0.7)
    clock.t += 5.0                       # no new command: dead-man timeout
    ctrl.step()
    assert (boat.left, boat.right) == (0.0, 0.0)


def test_manual_forward_blocked_by_obstacle_but_reverse_allowed():
    ctrl, boat, _ = make()
    boat.obstacle_cm = 30
    ctrl.drive(0.7, 0.7)
    ctrl.step()
    assert (boat.left, boat.right) == (0.0, 0.0)
    ctrl.drive(-0.5, -0.5)
    ctrl.step()
    assert boat.left < 0 and boat.right < 0


def test_estop_stops_everything_and_cuts_power():
    ctrl, boat, _ = make()
    ctrl.set_conveyor(True)
    ctrl.drive(0.7, 0.7)
    ctrl.set_estop(True)
    ctrl.step()
    assert (boat.left, boat.right) == (0.0, 0.0)
    assert boat.conveyor == 0.0 and boat.power_ok is False
    ctrl.set_estop(False)
    ctrl.step()
    assert boat.power_ok is True


def test_auto_obstacle_avoidance_backs_off_and_turns():
    ctrl, boat, _ = make()
    ctrl.set_mode(AUTO)
    boat.obstacle_cm = 20
    ctrl.step()
    assert boat.left < 0 < boat.right
    assert "obstacle" in ctrl.status["note"]


def test_conveyor_runs_in_auto_and_speeds_up_on_debris():
    ctrl, boat, _ = make()
    ctrl.set_mode(AUTO)
    ctrl.step()
    base = boat.conveyor
    boat.debris = 2
    ctrl.step()
    assert base > 0 and boat.conveyor > base


def test_simulated_mission_reaches_all_waypoints():
    wps = json.loads(pathlib.Path("sample_data/waypoints.json").read_text())["waypoints"]
    pts = [(w["lat"], w["lon"]) for w in wps]
    ctrl, boat, _ = make(waypoints=pts, lat=pts[0][0] - 0.0002, lon=pts[0][1])
    ctrl.set_mode(AUTO)
    dt = 0.1
    for _ in range(int(1800 / dt)):      # up to 30 simulated minutes
        ctrl.step()
        boat.step(dt)
        if ctrl.nav.done:
            break
    assert ctrl.nav.done, f"stopped at waypoint {ctrl.nav.index}"
