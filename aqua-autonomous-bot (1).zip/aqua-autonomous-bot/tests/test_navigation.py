from aqua_bot.navigation import Waypoint, WaypointNavigator


def nav(*pts, **kw):
    return WaypointNavigator([Waypoint(*p) for p in pts], **kw)


def test_target_ahead_drives_straight():
    n = nav((13.001, 80.0))
    c = n.update(13.0, 80.0, 0.0)
    assert c.left == c.right and c.left > 0


def test_target_to_right_turns_right():
    n = nav((13.0, 80.001))              # due east
    c = n.update(13.0, 80.0, 0.0)        # facing north
    assert c.left > c.right


def test_target_to_left_turns_left():
    n = nav((13.0, 79.999))              # due west
    c = n.update(13.0, 80.0, 0.0)
    assert c.right > c.left


def test_target_behind_pivots_in_place():
    n = nav((12.999, 80.0))
    c = n.update(13.0, 80.0, 0.0)
    assert c.left * c.right <= 0         # opposite or zero motor directions


def test_arrival_advances_then_completes():
    n = nav((13.0, 80.0), (13.001, 80.0), arrival_radius_m=3)
    c = n.update(13.0, 80.0, 0.0)        # already at waypoint 0
    assert c.waypoint_index == 1 and not c.done
    c = n.update(13.001, 80.0, 0.0)
    assert c.done and c.left == 0 and c.right == 0


def test_outputs_are_bounded():
    n = nav((14.0, 81.0), base_speed=1.0)
    c = n.update(13.0, 80.0, 200.0)
    assert -1 <= c.left <= 1 and -1 <= c.right <= 1
