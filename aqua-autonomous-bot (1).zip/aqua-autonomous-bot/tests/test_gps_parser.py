import pathlib
import pytest
from aqua_bot.gps_parser import checksum_ok, parse_gga

LINES = pathlib.Path(__file__).parent.parent.joinpath("sample_data/nmea_sample.txt").read_text().splitlines()


def test_valid_sentence_with_fix():
    lat, lon = parse_gga(LINES[0])
    assert lat == pytest.approx(13.0, abs=1e-6)
    assert lon == pytest.approx(80.0, abs=1e-6)


def test_no_fix_returns_none():
    assert checksum_ok(LINES[1])
    assert parse_gga(LINES[1]) is None


def test_bad_checksum_rejected():
    assert not checksum_ok(LINES[2])
    assert parse_gga(LINES[2]) is None


def test_southern_western_hemisphere_negative():
    body = "GPGGA,1,3351.000,S,15112.000,W,1,08,0.9,5.0,M,0.0,M,,"
    c = 0
    for ch in body:
        c ^= ord(ch)
    lat, lon = parse_gga(f"${body}*{c:02X}")
    assert lat < 0 and lon < 0
