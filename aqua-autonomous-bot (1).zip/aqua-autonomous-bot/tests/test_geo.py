import pytest
from aqua_bot.geo import bearing_deg, haversine_m, wrap_180


def test_one_degree_latitude_is_about_111km():
    assert haversine_m(0, 0, 1, 0) == pytest.approx(111195, rel=0.01)


def test_zero_distance():
    assert haversine_m(13.0, 80.0, 13.0, 80.0) == pytest.approx(0, abs=1e-6)


def test_bearings_on_compass_points():
    assert bearing_deg(13, 80, 14, 80) == pytest.approx(0, abs=0.1)      # north
    assert bearing_deg(13, 80, 13, 81) == pytest.approx(90, abs=0.5)     # east
    assert bearing_deg(13, 80, 12, 80) == pytest.approx(180, abs=0.1)    # south
    assert bearing_deg(13, 80, 13, 79) == pytest.approx(270, abs=0.5)    # west


@pytest.mark.parametrize("a,expected", [(0, 0), (190, -170), (-190, 170), (360, 0), (180, -180)])
def test_wrap_180(a, expected):
    assert wrap_180(a) == pytest.approx(expected)
