from aqua_bot.dashboard import create_app
from .test_controller import make


def test_api_roundtrip():
    ctrl, boat, _ = make()
    client = create_app(ctrl).test_client()
    assert client.get("/").status_code == 200
    client.post("/api/mode", json={"mode": "MANUAL"})
    client.post("/api/drive", json={"left": 0.5, "right": 0.5})
    ctrl.step()
    s = client.get("/api/status").get_json()
    assert s["mode"] == "MANUAL" and s["left"] == 0.5
    client.post("/api/estop", json={"active": True})
    ctrl.step()
    assert client.get("/api/status").get_json()["estop"] is True
